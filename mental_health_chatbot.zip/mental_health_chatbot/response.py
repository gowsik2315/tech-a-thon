from stress_relief import get_breathing_exercise, get_relaxation_tip
from motivation import get_motivational_quote
from happiness_sadness_fearness import *
class ResponseGenerator:
    def generate_response(self, intent):
        if intent == "greeting":
            return "Hello! How can I assist you today?"
        elif intent == "stress_level":
            return get_relaxation_tip()
        elif intent == "happy":
            return happiness()
        elif intent == "sad":
            return sadness()
        elif intent == "fear":
            return fearness()
        elif intent == "breathing_exercise":
            return get_breathing_exercise()
        elif intent == "motivational_quote":
            return get_motivational_quote()
        elif intent == "farewell":
            return "Goodbye! Take care!"
        else:
            return "I'm not sure how to help with that. Can you tell me more?"
