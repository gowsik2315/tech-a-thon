import random

def get_motivational_quote():
    quotes = [
        "Believe in yourself!",
        "Every day is a second chance.",
        "You are stronger than you think.",
        "Keep pushing forward.",
        "Success is not final; failure is not fatal: It is the courage to continue that counts.",
        "The road to success and the road to failure are almost exactly the same.",
        "Success usually comes to those who are too busy to be looking for it.",
        "Success is getting what you want; happiness is wanting what you get."
    ]
    return random.choice(quotes)
