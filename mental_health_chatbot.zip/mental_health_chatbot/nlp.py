import re
class IntentClassifier:
    def __init__(self):
        self.intents = {
            "greeting": ["hello", "hi", "hey"],
            "stress_level": ['stressed','anxious','overwhelmed','nervous','pressure',],
            "sad": ['sad','depressed','heartbroken','melancholy','mournful','pessimistic','somber','sorrowful','sorry','unhappy','upset'],
            'happy':['happy','cheerful','delighted','ecstatic','elated','exultant','glad','gleeful','jolly','jubilant','merry','mirthful','overjoyed','thrilled','up','beat','blessed','blissful','blithe','content','contented','convivial','gratified','peaceful','pleasant','pleased','satisfied','sparkling','sunny','tickled'],
            'fear':['fear','alarm','angst','anxiety','apprehension','awe','concern','despair','dismay','doubt','dread','horror','jitters','panic','scare','suspicion','terror','unease','uneasiness','worry'],
            "breathing_exercise": ["breathe", 'breathing', "relax",'calm', 'peace','unwind','decompress'],
            "motivational_quote": ['motivational','inspire','encoureagement','quote','motivated','motivate','inspiration',],
            "farewell": ["bye", "goodbye", "see you",'thank you']
        }

    def predict_intent(self, text):
        text = text.lower()
        for intent, keywords in self.intents.items():
            for keyword in keywords:
                if re.search(rf'\b{keyword}\b',text):
                    return intent
        return "unknown"