from nlp import IntentClassifier
from response import ResponseGenerator

def main():
    classifier = IntentClassifier()
    response_generator = ResponseGenerator()

    print("Welcome to the Stress Relief Chatbot!")
    intent = 'unknown'
    while True:
        if intent == "farewell":
            break
        user_input = input("You: ")
        intent = classifier.predict_intent(user_input)
        response = response_generator.generate_response(intent)
        print(f"Chatbot: {response}")

if __name__ == "__main__":
    main()