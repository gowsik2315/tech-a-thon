import random
def happiness():
    responses = ["That's awesome to hear! I'm so glad you're feeling happy!",
                "Yay! I'm thrilled that you're in a good mood today!",
                "What's making you feel happy today? I'd love to hear about it!",
                "It's great to hear that!",
                "You could share your good mood with others. Maybe send a message to a friend and brighten their day too!",
                "Keep smiling! You're spreading positivity around you.",
                "It's wonderful to see you happy. Remember, happiness is contagious, so keep it going!",
                "Happiness is precious. Hold onto this moment and remember what made you smile today."
            ]
    return random.choice(responses)

def sadness():
    responses = ["I'm really sorry to hear that you're feeling sad. I'm here for you.",
                 "It's okay to feel sad sometimes. Maybe try listening to some music to lighten up the mood",
                 "Would you like to try a quick breathing exercise to help you feel a bit better?",
                 "Sometimes it helps to take a break and do something nice for yourself. Can I suggest a relaxation exercise?",
                 "Remember, it's okay to have tough days. 'This too shall pass.' Stay strong.",
                 "'The sun will rise, and we will try again.' You're stronger than you think.",
                 "How about we try a short breathing exercise together? It might help you feel more at ease.",
                 "You're not alone. If you need more help, consider reaching out to a professional."
            ]
    return random.choice(responses)

def fearness():
    responses = ["I'm sorry you're feeling afraid right now. I'm here to help you through this.",
                 "It's okay to feel scared sometimes. You're not alone in this.",
                 "You're safe right now. Take a deep breath, and let's work through this together.",
                 "Fear can be overwhelming, but remember, you have the strength to get through this.",
                 "Try to focus on your breathing. Take slow, deep breaths to help calm your mind.",
                 "Let's try a simple exercise: Can you name 5 things you can see around you? This can help ground you.",
                 "You're doing great, even when things feel tough. It's okay to take things one step at a time.",
                 "I'm here with you. Sometimes it helps to talk about what's making you feel afraid.",
                 "If you're feeling overwhelmed, it might help to talk to someone you trust. I can suggest some resources if you'd like.",
                 "It's important to take care of yourself. If you need more support, don't hesitate to reach out to a professional."
            ]
    return random.choice(responses)