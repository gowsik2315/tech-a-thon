def get_breathing_exercise():
    return "Inhale deeply through your nose, hold for 4 seconds, then exhale slowly through your mouth. Repeat 5 times."

def get_relaxation_tip():
    return "Take a moment to close your eyes and focus on your breathing. Let go of any tension in your body."
